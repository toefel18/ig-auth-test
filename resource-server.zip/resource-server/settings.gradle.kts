rootProject.name = "resource-server"
